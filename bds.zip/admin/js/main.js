const exceptionCode = 417;
var token = localStorage.getItem("token");
$(document).ready(function() {
    loadmenu();
    checkroleAdmin();
    function loadmenu(){
        var content = 
            `<a class="nav-link" href="index.html">
                <div class="sb-nav-link-icon"><i class="fas fa-home iconmenu"></i></div>
                Tổng quan
            </a>
            <div class="sb-sidenav-menu-heading">Quản lý</div>
            <a class="nav-link" href="user.html">
                <div class="sb-nav-link-icon"><i class="fas fa-user-alt iconmenu"></i></div>
                Tài khoản
            </a>
            <a class="nav-link" href="blog.html">
                <div class="sb-nav-link-icon"><i class="fas fa-newspaper iconmenu"></i></div>
                Bài viết
            </a>
            <a class="nav-link" href="category.html">
                <div class="sb-nav-link-icon"><i class="fas fa-table iconmenu"></i></div>
                Danh mục
            </a>
            <a class="nav-link" href="tindang.html">
                <div class="sb-nav-link-icon"><i class="fas fa-home iconmenu"></i></div>
                Tin đăng
            </a>
            <a class="nav-link" href="doanhthu.html">
                <div class="sb-nav-link-icon"><i class="fas fa-link iconmenu"></i></div>
                Doanh thu
            </a>
            <a class="nav-link" href="lichsunap.html">
                <div class="sb-nav-link-icon"><i class="fas fa-link iconmenu"></i></div>
                Lịch sử nạp tiền
            </a>
            <a onclick="logout()" class="nav-link" href="#">
                <div class="sb-nav-link-icon"><i class="fas fa-sign-out-alt iconmenu"></i></div>
                Đăng xuất
            </a>
           `

        var menu =
        `<nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
            <div class="nav">
                ${content}
            </div>
        </div>
    </nav>`
    document.getElementById("layoutSidenav_nav").innerHTML = menu
    }
    loadtop()
    function loadtop(){
        var top =
        `<a class="navbar-brand ps-3" href="index.html">Quản trị hệ thống</a>
        <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
        <form class="d-none d-md-inline-block form-inline ms-auto me-0 me-md-3 my-2 my-md-0"></form>
        <ul id="menuleft" class="navbar-nav ms-auto ms-md-0 me-3 me-lg-4">
        </ul>`
        document.getElementById("top").innerHTML = top
    }
    var sidebarToggle = document.getElementById("sidebarToggle");
    sidebarToggle.onclick = function(){
        document.body.classList.toggle('sb-sidenav-toggled');
        localStorage.setItem('sb|sidebar-toggle', document.body.classList.contains('sb-sidenav-toggled'));
    }
});

async function logout(){
    localStorage.removeItem("token");
    localStorage.removeItem("role");
    window.location.replace('../dangnhap.html')
}


function formatmoney(money) {
    const VND = new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND',
      });
    return VND.format(money);
}

async function checkroleAdmin(){
    var token = localStorage.getItem("token");
    var url = 'http://localhost:8080/api/admin/check-role-admin';
    const response = await fetch(url, {
        method: 'GET',
        headers: new Headers({
            'Authorization': 'Bearer ' + token
        })
    });
    if(response.status > 300){
        window.location.replace('../dangnhap.html')
    }
}


function offComplete(){
    $("input[type='search']").wrap("<form>");
    $("input[type='search']").closest("form").attr("autocomplete","off");
}